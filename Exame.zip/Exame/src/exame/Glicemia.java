/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exame;

import javax.swing.JOptionPane;

/**
 *
 * @author janai
 */
public class Glicemia extends Exame {
    
    private int quant;
    
    public void setQuant (int quant){
       this.quant = quant;
   }
   
    public int getQuant(){
        return this.quant;
        
    }
    
    public void classificarresultado(){
        this.quant = quant;
        if (this.quant > 126)
            JOptionPane.showMessageDialog(null,"Glicemia: "+this.quant+ "mg/dl"+"\nPaciente Diabético");
        else
            if (this.quant > 100)
                JOptionPane.showMessageDialog(null,"Glicemia: "+this.quant+ "\nPaciente pré diabético");
       
            else   
                JOptionPane.showMessageDialog(null,"Glicemia: "+this.quant+"\nPaciente Normoglicemia");
        
        }
    }

        

