/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exame;

import javax.swing.JOptionPane;

/**
 *
 * @author janai
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Exame exame = new Exame();
        Glicemia exg = new Glicemia();
        Colesterol col = new Colesterol();
        Triglicerideos trig = new Triglicerideos();
                   
        exame.setpaciente("Janaina da Rocha Pereira de Moraes");
        exame.setnascimento("12/07/1982");
        exame.settiposanguineo("A+");
        exame.setAno(2023);
        int idade=2023-1982;
        
        trig.setId(idade);
        col.setId(idade);
        
        exg.setQuant(75);
        col.sethdl(80);
        col.setldl(75);
        trig.setValor(100);
         
           
        JOptionPane.showMessageDialog(null, "Paciente: "+exame.getpaciente()+ "\n Idade: " + idade + " anos"+ "\n" +"Tipo sanguineo:  "+ exame.gettiposanguineo());
        exg.classificarresultado();
        col.classificarresultado();
        trig.classificarresultado();
      
       
        
                
        
    }
    
}
    
    
    

