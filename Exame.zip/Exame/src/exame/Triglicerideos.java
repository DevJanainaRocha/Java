/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exame;

import javax.swing.JOptionPane;

/**
 *
 * @author janai
 */
   public class Triglicerideos extends Exame {

    private int valor;
    private int id;
    
    public void classificarresultado(){
        if (this.id <=9 && this.valor<75)
           JOptionPane.showMessageDialog(null, "Triglicerídeo = " +this.valor+ "mg/dl \n" + "Valor adequado para idade");
         if (this.id <=19 && this.valor<90)
           JOptionPane.showMessageDialog(null, "Triglicerídeo = " +this.valor+ "mg/dl \n" + "Valor adequado para idade"); 
         if (this.id <20 && this.valor<150)
           JOptionPane.showMessageDialog(null, "Triglicerídeo = " +this.valor+ "mg/dl \n" + "Valor adequado para idade");
         else
           JOptionPane.showMessageDialog(null, "Triglicerídeo = " +this.valor+ "mg/dl \n" + "Valor fora da referência adequada");
             
    }
    
    
    public void setValor (int valor){
        this.valor = valor;
    }
    
    public int getValor(){
        return this.valor;
    }
    public void setId (int id){
        this.valor = valor;
    }
    
    public int getId(){
        return this.valor;
    }
}


    

