/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exame;

import javax.swing.JOptionPane;

/**
 *
 * @author janai
 */
public class Colesterol extends Exame {
    
   private int LDL;
   private int HDL;
   private int id;
   
   public void classificarresultado(){
       if (this.id <=19 && this.HDL>45)
           JOptionPane.showMessageDialog(null, "HDL: "+this.HDL+ "mg/dl \n"+ "Compatível com valores de referência");
       if (this.id >20 && this.HDL>40)
           JOptionPane.showMessageDialog(null, "HDL: "+this.HDL+ "mg/dl \n"+ "Compatível com valores de referência");
        else
           JOptionPane.showMessageDialog(null, "LDL: "+this.HDL+"mg/dl \n"+ "Colesterol Alto");
       if (this.LDL>70&&this.LDL<100) 
           JOptionPane.showMessageDialog(null, "LDL: "+this.LDL+"mg/dl \n"+ "Adequado para paciente Risco baixo");
       if (this.LDL<=70&& this.LDL>50)
           JOptionPane.showMessageDialog(null, "LDL: "+this.LDL+"mg/dl \n"+ "Adequado para paciente Risco médio");
        else
       if (this.LDL<50)
           JOptionPane.showMessageDialog(null, "LDL: "+this.LDL+"mg/dl \n"+ "Adequado para paciente Risco alto");
         
    }
   
     public void setId (int id){
         this.id = id;
   }
   
       public int getId (){
         return this.id;
   }
   
      
       public void setldl (int LDL){
         this.LDL = LDL;
   }
   
       public int getldl (){
         return this.LDL;
   }
   
      public void sethdl (int HDL){
          this.HDL = HDL;
   }
      
      public int gethdl (){
         return this.HDL;
   }
   
    
}

    

