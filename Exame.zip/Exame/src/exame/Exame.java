/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exame;

/**
 *
 * @author janai
 */
public class Exame {
    private String Nascimento;
    private String Paciente;
    private String Tiposanguineo;
    private int ano;
    
     public void setnascimento (String Nascimento){
        this.Nascimento = Nascimento;
    }
    
    public String getnascimento(){
        return this.Nascimento;
    
    }
    public void setpaciente (String Paciente){
        this.Paciente = Paciente;
    }
    
    public String getpaciente(){
        return this.Paciente;
    
    }
    public void settiposanguineo (String Tiposanguineo){
        this.Tiposanguineo = Tiposanguineo;
    }
    
    public String gettiposanguineo(){
        return this.Tiposanguineo;
    
    }
    public int getAno(){
        return this.ano;
    
    }
    public void setAno (int ano){
        this.ano = ano;
    }
}
